import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, Slider
import matplotlib.animation as animation
from matplotlib.colors import ListedColormap
import heapq
import time
import random


class Node:
    """Node class for A* Pathfinding"""

    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.g = 0  # Cost from start to current node
        self.h = 0  # Heuristic (estimated cost from current node to end)
        self.f = 0  # Total cost: f = g + h

    def __eq__(self, other):
        return self.position == other.position

    def __lt__(self, other):
        return self.f < other.f


def astar(maze, start, end, ax=None, fig=None, visualize=True):
    """
    Returns a list of tuples as a path from the given start to the given end in the given maze
    """
    # Create start and end node
    start_node = Node(None, start)
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, end)
    end_node.g = end_node.h = end_node.f = 0

    # Initialize open and closed lists
    open_list = []
    closed_list = set()  # Using a set for O(1) membership check

    # Add the start node
    heapq.heappush(open_list, start_node)

    # Update visualization with initial state
    if visualize and ax is not None and fig is not None:
        ax.clear()
        # Prepare maze with color markers for display
        maze_display = maze.copy()
        maze_display[start] = 2  # 2 represents start
        maze_display[end] = 3  # 3 represents end

        # Create color map
        cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
        ax.imshow(maze_display, cmap=cmap)

        # Add grid
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

        # Draw S and E markers
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

        ax.set_title('Robot Path Finding - Searching...')
        fig.canvas.draw_idle()

    # Keep track of visited positions for visualization
    visited = []

    # Loop until you find the end
    while open_list:
        # Get the current node
        current_node = heapq.heappop(open_list)

        # Add current position to closed list
        closed_list.add(current_node.position)

        # Add current position to visited
        visited.append(current_node.position)

        # Visualize the search process
        if visualize and ax is not None and fig is not None and len(
                visited) % 5 == 0:  # Update every 5 steps to speed up visualization
            for y, x in visited[-5:]:  # Only plot the new points
                if (y, x) != start and (y, x) != end:
                    ax.plot(x, y, 'yo', markersize=5, alpha=0.3)
            fig.canvas.draw_idle()
            plt.pause(0.001)

        # Found the goal
        if current_node.position == end_node.position:
            path = []
            current = current_node
            while current is not None:
                path.append(current.position)
                current = current.parent

            # Reverse path to get start-to-end order
            path = path[::-1]

            # Visualize the final path
            if visualize and ax is not None and fig is not None:
                path_x = [pos[1] for pos in path]
                path_y = [pos[0] for pos in path]

                # Remove existing path lines if any
                for line in ax.lines:
                    if line.get_label() == 'Path':
                        line.remove()

                ax.plot(path_x, path_y, 'r-', linewidth=2, label='Path')

                # Clear previous path numbers if any
                for txt in ax.texts:
                    if txt.get_text() not in ['S', 'E']:
                        txt.remove()

                for i, (y, x) in enumerate(path):
                    if i > 0 and i < len(path) - 1:  # Skip start and end
                        ax.text(x, y, str(i), color='black', fontsize=8,
                                ha='center', va='center')

                ax.set_title(f"Path found! Length: {len(path)}")
                fig.canvas.draw_idle()

            return path  # Return path immediately when goal is found

        # Generate children
        # Adjacent movements: Up, Down, Left, Right
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            # Get node position
            node_position = (current_node.position[0] + new_position[0],
                             current_node.position[1] + new_position[1])

            # Make sure within range
            if (node_position[0] < 0 or node_position[0] >= maze.shape[0] or
                    node_position[1] < 0 or node_position[1] >= maze.shape[1]):
                continue

            # Make sure walkable terrain (not an obstacle)
            if maze[node_position[0], node_position[1]] == 1:
                continue

            # Skip if in closed list
            if node_position in closed_list:
                continue

            # Create new node
            new_node = Node(current_node, node_position)

            # Create the f, g, and h values
            new_node.g = current_node.g + 1
            # Heuristic is Manhattan distance to the end
            new_node.h = abs(new_node.position[0] - end_node.position[0]) + abs(
                new_node.position[1] - end_node.position[1])
            new_node.f = new_node.g + new_node.h

            # Check if this node is already in the open list with a better g score
            skip = False
            for i, open_node in enumerate(open_list):
                if open_node.position == new_node.position:
                    if new_node.g >= open_node.g:
                        skip = True
                        break
                    else:
                        # Replace with better node
                        open_list[i] = new_node
                        # Reheapify
                        heapq.heapify(open_list)
                        skip = True
                        break

            if not skip:
                # Add the child to the open list
                heapq.heappush(open_list, new_node)

    # No path found
    if visualize and ax is not None and fig is not None:
        ax.set_title("No path found!")
        fig.canvas.draw_idle()
    return None


def create_example_maze(size=20):
    """Create a maze based on the example provided in the assignment"""
    # Create a maze with specified size
    maze = np.zeros((size, size), dtype=int)

    # Add obstacles (1 represents obstacles)
    # Creating a pattern similar to the one in the assignment
    # Horizontal barrier
    maze[size // 4:size // 3, size // 6:3 * size // 4] = 1

    # Vertical barrier
    maze[size // 3:3 * size // 4, 3 * size // 5:3 * size // 4] = 1

    # Leave opening in barriers
    maze[size // 4 + 1, 2 * size // 5:size // 2] = 0

    # Another obstacle
    maze[3 * size // 5:4 * size // 5, size // 4:2 * size // 5] = 1

    return maze


def create_correct_maze():
    """Create the 8x9 maze based on the image from the assignment"""
    # Create an 8-column, 9-row maze (height 9, width 8)
    maze = np.zeros((9, 8), dtype=int)

    # Set obstacles (blue areas)
    # Left vertical obstacle
    maze[1:4, 1] = 1
    maze[7, 1] = 1
    # Top horizontal obstacle
    maze[1, 1:4] = 1
    # Right vertical obstacle
    maze[1:7, 4] = 1
    # Bottom horizontal obstacle
    maze[7, 1:5] = 1

    return maze


def generate_random_maze(size=20, obstacle_density=0.3, min_path_width=2):
    """
    Generate a random maze with a specified size and obstacle density
    Ensures there's always a path from start to end by using a cellular automaton approach
    """
    # Initialize with random obstacles
    maze = np.zeros((size, size), dtype=int)
    for i in range(size):
        for j in range(size):
            # Keep edges clear
            if i < 2 or i >= size - 2 or j < 2 or j >= size - 2:
                maze[i, j] = 0
            else:
                maze[i, j] = 1 if random.random() < obstacle_density else 0

    # Apply cellular automaton rules to create more natural looking obstacles
    for _ in range(3):
        new_maze = np.copy(maze)
        for i in range(1, size - 1):
            for j in range(1, size - 1):
                # Count neighbors
                neighbors = np.sum(maze[i - 1:i + 2, j - 1:j + 2]) - maze[i, j]

                # Apply rules
                if neighbors > 4:
                    new_maze[i, j] = 1
                elif neighbors < 3:
                    new_maze[i, j] = 0
        maze = new_maze

    # Ensure start and end areas are clear
    start_area = (0, 0, 3, 3)  # (top, left, height, width)
    end_area = (size - 3, size - 3, 3, 3)

    for area in [start_area, end_area]:
        top, left, height, width = area
        maze[top:top + height, left:left + width] = 0

    # Ensure there are some clear paths
    for i in range(min_path_width, size - min_path_width, min_path_width):
        # Create horizontal and vertical paths
        if random.random() < 0.7:
            maze[i, :] = 0
        if random.random() < 0.7:
            maze[:, i] = 0

    return maze


def create_animation(maze, start, end):
    """Create animation of path finding process"""
    # Create start and end node
    start_node = Node(None, start)
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, end)
    end_node.g = end_node.h = end_node.f = 0

    # Initialize open and closed lists
    open_list = []
    closed_list = set()

    # Add the start node
    heapq.heappush(open_list, start_node)

    # Record each step's state
    frames = []
    frames.append(([], [], None))  # Initial state: no visited points, no path

    visited = []
    final_path = None

    # Create figure and axis
    fig, ax = plt.subplots(figsize=(10, 10))
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])

    # Add Exit button instead of Return button
    button_ax = plt.axes([0.8, 0.01, 0.15, 0.05])
    exit_button = Button(button_ax, 'Exit')

    def on_exit_clicked(event):
        plt.close(fig)

    exit_button.on_clicked(on_exit_clicked)

    # Animation function
    def animate(i):
        if i < len(frames):
            current_frame = frames[i]
            update_plot(current_frame)
        return ax,

    def update_plot(frame_data):
        visited_nodes, open_nodes, path = frame_data

        ax.clear()

        # Prepare maze copy for animation
        maze_display = maze.copy()
        maze_display[start] = 2  # 2 represents start
        maze_display[end] = 3  # 3 represents end

        # Display maze
        ax.imshow(maze_display, cmap=cmap)

        # Add grid
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

        # Draw S and E markers
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

        # Draw visited nodes only up to current frame
        for y, x in visited_nodes:
            if (y, x) != start and (y, x) != end:
                ax.plot(x, y, 'yo', markersize=8, alpha=0.5)

        # If path exists, draw path
        if path:
            path_y = [pos[0] for pos in path]
            path_x = [pos[1] for pos in path]
            ax.plot(path_x, path_y, 'r-', linewidth=3, alpha=0.7)

            # Add numbers to path
            for i, (y, x) in enumerate(path):
                if i > 0 and i < len(path) - 1:  # Skip start and end
                    ax.text(x, y, str(i), color='black', fontsize=9,
                            ha='center', va='center', fontweight='bold')

            ax.set_title(f'Path found! Length: {len(path)}')
        else:
            if len(visited_nodes) > 0 and frames.index(frame_data) == len(frames) - 1 and not final_path:
                ax.set_title('No path found!')
            else:
                ax.set_title('Searching...')

    def update_frames():
        """Perform A* search and update frames"""
        nonlocal open_list, closed_list, visited, final_path, frames

        # Create a list to track nodes that we've examined (not just visited)
        examined_nodes = []

        # Main search loop
        while open_list:
            # Get the current node with lowest f score
            current_node = heapq.heappop(open_list)

            # Check if reached end immediately
            if current_node.position == end_node.position:
                # Reconstruct path
                path = []
                current = current_node
                while current is not None:
                    path.append(current.position)
                    current = current.parent
                path = path[::-1]

                # Add to visited for visualization
                if current_node.position not in visited:
                    visited.append(current_node.position)

                # Save final path
                final_path = path

                # Record final state with path
                current_open_nodes = list(open_list)
                frames.append((list(visited), [], path))

                # Exit the search loop
                break

            # If not at goal, process this node
            closed_list.add(current_node.position)
            if current_node.position not in visited:
                visited.append(current_node.position)

            # Record current state (only once per several nodes to reduce frame count)
            if len(visited) % 3 == 0:  # Record every 3rd node to reduce animation frames
                current_open_nodes = []  # Don't show open list to simplify visualization
                frames.append((list(visited), current_open_nodes, None))

            # Generate children nodes
            for direction in [(0, -1), (0, 1), (-1, 0), (1, 0)]:  # Adjacent directions
                node_position = (current_node.position[0] + direction[0],
                                 current_node.position[1] + direction[1])

                # Skip if already examined
                if node_position in examined_nodes:
                    continue

                # Add to examined nodes
                examined_nodes.append(node_position)

                # Check if valid position
                if (node_position[0] < 0 or node_position[0] >= maze.shape[0] or
                        node_position[1] < 0 or node_position[1] >= maze.shape[1]):
                    continue

                # Check if walkable
                if maze[node_position[0], node_position[1]] == 1:
                    continue

                # Check if in closed list
                if node_position in closed_list:
                    continue

                # Create new node
                new_node = Node(current_node, node_position)

                # Set g, h, f values
                new_node.g = current_node.g + 1
                new_node.h = abs(node_position[0] - end[0]) + abs(node_position[1] - end[1])
                new_node.f = new_node.g + new_node.h

                # Check if already in open list with better g value
                skip = False
                for i, open_node in enumerate(open_list):
                    if open_node.position == new_node.position:
                        if new_node.g >= open_node.g:
                            skip = True
                            break
                        else:
                            # Replace with better node
                            open_list[i] = new_node
                            heapq.heapify(open_list)
                            skip = True
                            break

                if not skip:
                    heapq.heappush(open_list, new_node)

        # If no path found, add final state
        if not final_path:
            frames.append((list(visited), [], None))

    # Run A* and collect frames
    update_frames()

    # Create animation - Set repeat=False to prevent looping
    ani = animation.FuncAnimation(fig, animate, frames=len(frames),
                                  interval=200, blit=True, repeat=False)

    plt.tight_layout()
    plt.show()

    return ani, fig


def save_maze(maze, filename='maze.npy'):
    """Save the maze to a file"""
    np.save(filename, maze)
    print(f"Maze saved to {filename}")


def load_maze(filename='maze.npy'):
    """Load the maze from a file"""
    try:
        return np.load(filename)
    except:
        print(f"Could not load {filename}. Creating example maze instead.")
        return create_example_maze()


def update_maze_plot(ax, maze, start, end):
    """Update the plot with current maze, start and end points"""
    ax.clear()

    # Prepare maze with color markers for display
    maze_display = maze.copy()
    maze_display[start] = 2  # 2 represents start
    maze_display[end] = 3  # 3 represents end

    # Create color map
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
    ax.imshow(maze_display, cmap=cmap)

    # Add grid
    ax.grid(color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

    # Draw S and E markers
    ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

    return ax


def solve_maze_simple(maze_type='example'):
    """Simple version: directly solve the maze and display results"""
    # Create maze based on type
    if maze_type == 'correct':
        maze = create_correct_maze()
        start = (2, 3)  # S coordinates (row, column)
        end = (4, 7)  # E coordinates (row, column)
    else:  # example
        maze = create_example_maze()
        maze_size = maze.shape[0]
        start = (2, 2)  # Start point near top-left
        end = (maze_size - 3, maze_size - 3)  # End point near bottom-right

    # Use A* algorithm to find path
    print("Using A* algorithm to find path...")
    start_time = time.time()
    path = astar(maze, start, end, visualize=False)
    end_time = time.time()

    if path:
        print(f"Path found! Length: {len(path)}")
        print(f"Path: {path}")
        print(f"Search time: {end_time - start_time:.6f} seconds")
    else:
        print("No path found!")

    # Prepare maze with color markers for display
    maze_display = maze.copy()
    maze_display[start] = 2  # 2 represents start
    maze_display[end] = 3  # 3 represents end

    # Create color map
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])

    # Visualize results
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.imshow(maze_display, cmap=cmap)

    # Add grid
    ax.grid(color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

    # Draw S and E markers
    ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

    # If path exists, draw path
    if path:
        path_y = [pos[0] for pos in path]
        path_x = [pos[1] for pos in path]
        ax.plot(path_x, path_y, 'r-', linewidth=3, alpha=0.7)

        # Add numbers to path
        for i, (y, x) in enumerate(path):
            if i > 0 and i < len(path) - 1:  # Skip start and end
                ax.text(x, y, str(i), color='black', fontsize=9,
                        ha='center', va='center', fontweight='bold')

        ax.set_title(f"Robot Path Finding - Path found! Length: {len(path)}")
    else:
        ax.set_title("Robot Path Finding - No path found!")

    plt.tight_layout()
    plt.show()

    return maze, start, end, path


def run_interactive_pathfinding():
    """Interactive demo with buttons for pathfinding simulation"""
    # Create the main figure and axes
    fig = plt.figure(figsize=(12, 10))

    # Create a grid layout
    grid = plt.GridSpec(8, 1, height_ratios=[5, 0.2, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3])

    # Maze display area
    ax = plt.subplot(grid[0])

    # Button areas
    ax_button1 = plt.subplot(grid[2])
    ax_button2 = plt.subplot(grid[3])
    ax_button3 = plt.subplot(grid[4])
    ax_button4 = plt.subplot(grid[5])
    ax_button5 = plt.subplot(grid[6])
    ax_slider = plt.subplot(grid[7])

    # Hide axes for button areas
    ax_button1.axis('off')
    ax_button2.axis('off')
    ax_button3.axis('off')
    ax_button4.axis('off')
    ax_button5.axis('off')

    # Initialize with example maze
    maze = create_example_maze()
    maze_size = maze.shape[0]

    # Define start and end points
    start = (2, 2)  # Start point near top-left
    end = (maze_size - 3, maze_size - 3)  # End point near bottom-right

    # Initialize variables
    setting_start = False
    setting_end = False
    obstacle_density = 0.3  # Default obstacle density

    # Display initial maze
    update_maze_plot(ax, maze, start, end)
    ax.set_title("Robot Path Finding - Click on grid to add/remove obstacles")

    # Add buttons with proper positioning
    # Row 1 buttons
    ax_start_search = plt.axes([0.15, 0.28, 0.2, 0.05])
    ax_set_start = plt.axes([0.4, 0.28, 0.2, 0.05])
    ax_set_end = plt.axes([0.65, 0.28, 0.2, 0.05])

    # Row 2 buttons
    ax_clear = plt.axes([0.15, 0.22, 0.2, 0.05])
    ax_random_maze = plt.axes([0.4, 0.22, 0.2, 0.05])
    ax_example_maze = plt.axes([0.65, 0.22, 0.2, 0.05])

    # Row 3 buttons
    ax_correct_maze = plt.axes([0.15, 0.16, 0.2, 0.05])
    ax_show_animation = plt.axes([0.4, 0.16, 0.2, 0.05])
    ax_show_coords = plt.axes([0.65, 0.16, 0.2, 0.05])

    # Row 4 buttons
    ax_save = plt.axes([0.15, 0.10, 0.2, 0.05])
    ax_load = plt.axes([0.4, 0.10, 0.2, 0.05])
    ax_exit = plt.axes([0.65, 0.10, 0.2, 0.05])

    # Add slider for obstacle density
    ax_obstacle_slider = plt.axes([0.2, 0.04, 0.6, 0.03])
    slider_obstacle = Slider(ax_obstacle_slider, 'Obstacle Density', 0.1, 0.6, valinit=obstacle_density, valstep=0.05)

    # Create buttons
    btn_start_search = Button(ax_start_search, 'Start Search')
    btn_set_start = Button(ax_set_start, 'Set Start')
    btn_set_end = Button(ax_set_end, 'Set End')

    btn_clear = Button(ax_clear, 'Clear All')
    btn_random_maze = Button(ax_random_maze, 'Random Maze')
    btn_example_maze = Button(ax_example_maze, 'Example Maze')

    btn_correct_maze = Button(ax_correct_maze, 'Assignment Maze')
    btn_show_animation = Button(ax_show_animation, 'Show Animation')
    btn_show_coords = Button(ax_show_coords, 'Show Coordinates')

    btn_save = Button(ax_save, 'Save Maze')
    btn_load = Button(ax_load, 'Load Maze')
    btn_exit = Button(ax_exit, 'Exit')

    # Button callbacks
    def on_start_search(event):
        ax.set_title("Running A* algorithm...")
        fig.canvas.draw_idle()
        path = astar(maze, start, end, ax, fig)
        if not path:
            ax.set_title("No path found!")

    def on_set_start(event):
        nonlocal setting_start, setting_end
        setting_start = True
        setting_end = False
        ax.set_title("Click to set Start point")
        fig.canvas.draw_idle()

    def on_set_end(event):
        nonlocal setting_start, setting_end
        setting_start = False
        setting_end = True
        ax.set_title("Click to set End point")
        fig.canvas.draw_idle()

    def on_clear(event):
        nonlocal maze
        maze = np.zeros_like(maze)
        update_maze_plot(ax, maze, start, end)
        ax.set_title("Robot Path Finding - Grid cleared")
        fig.canvas.draw_idle()

    def on_random_maze(event):
        nonlocal maze, obstacle_density
        # Generate new random maze with current density
        maze = generate_random_maze(size=maze_size, obstacle_density=obstacle_density)
        update_maze_plot(ax, maze, start, end)
        ax.set_title(f"Robot Path Finding - Random maze generated (Density: {obstacle_density:.2f})")
        fig.canvas.draw_idle()

    def on_example_maze(event):
        nonlocal maze
        maze = create_example_maze(size=maze_size)
        update_maze_plot(ax, maze, start, end)
        ax.set_title("Robot Path Finding - Example maze loaded")
        fig.canvas.draw_idle()

    def on_correct_maze(event):
        nonlocal maze, start, end, maze_size
        maze = create_correct_maze()
        maze_size = maze.shape[0]
        start = (2, 3)  # S coordinates (row, column)
        end = (4, 7)  # E coordinates (row, column)
        update_maze_plot(ax, maze, start, end)
        ax.set_title("Robot Path Finding - Assignment maze loaded")
        fig.canvas.draw_idle()

    def on_show_animation(event):
        plt.close(fig)  # Close current window
        create_animation(maze, start, end)

    def on_show_coords(event):
        ax.clear()
        # Show maze with color markers
        maze_display = maze.copy()
        maze_display[start] = 2
        maze_display[end] = 3
        cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
        ax.imshow(maze_display, cmap=cmap)
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)
        # Show coordinates
        for i in range(maze.shape[0]):
            for j in range(maze.shape[1]):
                ax.text(j, i, f'({i},{j})', ha='center', va='center',
                        color='black', fontsize=7)
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')
        ax.set_title('Maze Layout - Showing Coordinates')
        fig.canvas.draw_idle()

    def on_save(event):
        try:
            save_maze(maze)
            ax.set_title("Maze saved successfully!")
        except Exception as e:
            ax.set_title(f"Error saving maze: {str(e)}")
        fig.canvas.draw_idle()

    def on_load(event):
        nonlocal maze, maze_size
        try:
            maze = load_maze()
            maze_size = maze.shape[0]
            update_maze_plot(ax, maze, start, end)
            ax.set_title("Maze loaded successfully!")
        except Exception as e:
            ax.set_title(f"Error loading maze: {str(e)}")
        fig.canvas.draw_idle()

    def on_exit(event):
        plt.close(fig)

    def on_density_change(val):
        nonlocal obstacle_density
        obstacle_density = val
        ax.set_title(f"Obstacle density set to: {val:.2f}")
        fig.canvas.draw_idle()

    # Connect button callbacks
    btn_start_search.on_clicked(on_start_search)
    btn_set_start.on_clicked(on_set_start)
    btn_set_end.on_clicked(on_set_end)
    btn_clear.on_clicked(on_clear)
    btn_random_maze.on_clicked(on_random_maze)
    btn_example_maze.on_clicked(on_example_maze)
    btn_correct_maze.on_clicked(on_correct_maze)
    btn_show_animation.on_clicked(on_show_animation)
    btn_show_coords.on_clicked(on_show_coords)
    btn_save.on_clicked(on_save)
    btn_load.on_clicked(on_load)
    btn_exit.on_clicked(on_exit)
    slider_obstacle.on_changed(on_density_change)

    # Click callback for grid
    def on_click(event):
        nonlocal maze, setting_start, setting_end, start, end

        if event.inaxes != ax:
            return

        x, y = int(round(event.xdata)), int(round(event.ydata))

        if x < 0 or x >= maze.shape[1] or y < 0 or y >= maze.shape[0]:
            return

        if setting_start:
            start = (y, x)
            update_maze_plot(ax, maze, start, end)
            setting_start = False
            ax.set_title("Start point set")
        elif setting_end:
            end = (y, x)
            update_maze_plot(ax, maze, start, end)
            setting_end = False
            ax.set_title("End point set")
        else:
            # Toggle obstacle
            maze[y, x] = 1 - maze[y, x]
            update_maze_plot(ax, maze, start, end)
            ax.set_title("Robot Path Finding - Obstacle toggled")

        fig.canvas.draw_idle()

    # Connect click handler
    fig.canvas.mpl_connect('button_press_event', on_click)

    plt.tight_layout()
    plt.show()

    return maze, start, end


if __name__ == "__main__":
    # Present options to user
    print("Robot Path Finding Demo")
    print("======================")
    print("Please select a run mode:")
    print("1. Simple Mode - Directly display results")
    print("2. Interactive Mode - Provide buttons and animation")
    print("3. Animation Mode - Show search process animation")

    try:
        choice = int(input("Enter option (1, 2, or 3): "))
        if choice == 1:
            print("Select maze type:")
            print("1. Example maze")
            print("2. Assignment maze")
            maze_choice = int(input("Enter option (1 or 2): "))
            if maze_choice == 2:
                solve_maze_simple('correct')
            else:
                solve_maze_simple('example')
        elif choice == 2:
            run_interactive_pathfinding()
        elif choice == 3:
            maze_choice = int(input("Select maze (1: Example, 2: Assignment): "))
            if maze_choice == 2:
                maze = create_correct_maze()
                start = (2, 3)  # S coordinates (row, column)
                end = (4, 7)  # E coordinates (row, column)
            else:
                maze = create_example_maze()
                maze_size = maze.shape[0]
                start = (2, 2)  # Start point near top-left
                end = (maze_size - 3, maze_size - 3)  # End point near bottom-right
            create_animation(maze, start, end)
        else:
            print("Invalid option, using Interactive Mode as default")
            run_interactive_pathfinding()
    except Exception as e:
        print(f"Input error: {str(e)}")
        print("Using Interactive Mode as default")
        run_interactive_pathfinding()