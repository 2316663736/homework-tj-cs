import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button
import matplotlib.animation as animation
from matplotlib.colors import ListedColormap
from collections import deque
import time


def bidirectional_bfs(maze, start, end, ax=None, fig=None, visualize=True):
    """
    Bidirectional BFS algorithm for path finding
    从起点和终点同时开始广度优先搜索，当两个搜索相遇时找到最短路径
    """
    if start == end:
        return [start]  # Already at destination

    # Initialize BFS queues
    start_queue = deque([start])
    end_queue = deque([end])

    # Track visited cells and their parents
    start_visited = {start: None}  # Maps positions to parent positions
    end_visited = {end: None}

    # Keep track of all visited positions for visualization
    all_visited = []

    # Update visualization with initial state
    if visualize and ax is not None and fig is not None:
        ax.clear()
        # Prepare maze with color markers for display
        maze_display = maze.copy()
        maze_display[start] = 2  # 2 represents start
        maze_display[end] = 3  # 3 represents end

        # Create color map
        cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
        ax.imshow(maze_display, cmap=cmap)

        # Add grid
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

        # Draw S and E markers
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

        ax.set_title('Robot Path Finding - Bidirectional BFS Searching...')
        fig.canvas.draw_idle()

    # Neighbor directions: Up, Down, Left, Right
    directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]

    # Function to expand search from one side
    def expand_search(queue, visited, other_visited):
        if not queue:
            return None

        # Get current position
        current = queue.popleft()

        # Explore all four directions
        for direction in directions:
            # Calculate new position
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            # Skip if already visited from this side
            if new_pos in visited:
                continue

            # Check bounds
            if (new_pos[0] < 0 or new_pos[0] >= maze.shape[0] or
                    new_pos[1] < 0 or new_pos[1] >= maze.shape[1]):
                continue

            # Check obstacle
            if maze[new_pos[0], new_pos[1]] == 1:
                continue

            # Mark as visited from this side
            visited[new_pos] = current

            # For visualization
            all_visited.append(new_pos)

            # Check if this position has been visited from the other side
            if new_pos in other_visited:
                # Found intersection - return the meeting point
                return new_pos

            # Add to queue for further exploration
            queue.append(new_pos)

        return None

    # Alternately expand from both sides until a path is found or search completes
    intersection_point = None

    while start_queue and end_queue:
        # Expand from start side
        intersection_point = expand_search(start_queue, start_visited, end_visited)
        if intersection_point:
            break

        # Expand from end side
        intersection_point = expand_search(end_queue, end_visited, start_visited)
        if intersection_point:
            break

        # Visualize the search process
        if visualize and ax is not None and fig is not None and len(all_visited) % 5 == 0:
            for i in range(min(5, len(all_visited))):
                if len(all_visited) > i:
                    y, x = all_visited[-i - 1]
                    if (y, x) != start and (y, x) != end:
                        ax.plot(x, y, 'yo', markersize=5, alpha=0.3)
            fig.canvas.draw_idle()
            plt.pause(0.001)

    # If no intersection found, no path exists
    if not intersection_point:
        if visualize and ax is not None and fig is not None:
            ax.set_title("No path found!")
            fig.canvas.draw_idle()
        return None

    # Reconstruct path
    path = []

    # Trace path from intersection to start
    current = intersection_point
    while current:
        path.append(current)
        current = start_visited[current]
    path = path[::-1]  # Reverse to get path from start

    # Remove intersection point to avoid duplication
    path.pop()

    # Trace path from intersection to end
    current = intersection_point
    while current:
        path.append(current)
        current = end_visited[current]

    # Visualize the final path
    if visualize and ax is not None and fig is not None:
        path_x = [pos[1] for pos in path]
        path_y = [pos[0] for pos in path]

        # Remove existing path lines if any
        for line in ax.lines:
            if line.get_label() == 'Path':
                line.remove()

        ax.plot(path_x, path_y, 'r-', linewidth=2, label='Path')

        # Clear previous path numbers if any
        for txt in ax.texts:
            if txt.get_text() not in ['S', 'E']:
                txt.remove()

        for i, (y, x) in enumerate(path):
            if i > 0 and i < len(path) - 1:  # Skip start and end
                ax.text(x, y, str(i), color='black', fontsize=8,
                        ha='center', va='center')

        ax.set_title(f"Path found! Length: {len(path)}")
        fig.canvas.draw_idle()

    return path


def update_animation_for_bidirectional_bfs(maze, start, end):
    """Create animation of Bidirectional BFS path finding process"""
    # Initialize BFS queues and visited dictionaries
    start_queue = deque([start])
    end_queue = deque([end])
    start_visited = {start: None}
    end_visited = {end: None}

    # Record each step's state
    frames = []
    frames.append(([], None))  # Initial state: no visited points, no path

    all_visited = []
    final_path = None
    intersection_point = None

    # Neighbor directions: Up, Down, Left, Right
    directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]

    # Function to expand search from one side and record frames
    def expand_search(queue, visited, other_visited, side):
        if not queue:
            return None

        # Get current position
        current = queue.popleft()

        # Record which side this position was visited from
        if side == 'start' and current not in all_visited:
            all_visited.append(('start', current))
        elif side == 'end' and current not in all_visited:
            all_visited.append(('end', current))

        # Explore all four directions
        for direction in directions:
            # Calculate new position
            new_pos = (current[0] + direction[0], current[1] + direction[1])

            # Skip if already visited from this side
            if new_pos in visited:
                continue

            # Check bounds
            if (new_pos[0] < 0 or new_pos[0] >= maze.shape[0] or
                    new_pos[1] < 0 or new_pos[1] >= maze.shape[1]):
                continue

            # Check obstacle
            if maze[new_pos[0], new_pos[1]] == 1:
                continue

            # Mark as visited from this side
            visited[new_pos] = current

            # Record which side this position was visited from
            if side == 'start':
                all_visited.append(('start', new_pos))
            else:
                all_visited.append(('end', new_pos))

            # Record current state (every few steps to reduce frame count)
            if len(all_visited) % 3 == 0:
                frames.append((list(all_visited), None))

            # Check if this position has been visited from the other side
            if new_pos in other_visited:
                # Found intersection - return the meeting point
                return new_pos

            # Add to queue for further exploration
            queue.append(new_pos)

        return None

    # Alternately expand from both sides until a path is found or search completes
    while start_queue and end_queue:
        # Expand from start side
        intersection_point = expand_search(start_queue, start_visited, end_visited, 'start')
        if intersection_point:
            break

        # Expand from end side
        intersection_point = expand_search(end_queue, end_visited, start_visited, 'end')
        if intersection_point:
            break

    # If intersection found, reconstruct path
    if intersection_point:
        path = []

        # Trace path from intersection to start
        current = intersection_point
        while current:
            path.append(current)
            current = start_visited[current]
        path = path[::-1]  # Reverse to get path from start

        # Remove intersection point to avoid duplication
        path.pop()

        # Trace path from intersection to end
        current = intersection_point
        while current:
            path.append(current)
            current = end_visited[current]

        final_path = path
        # Add final frame with path
        frames.append((list(all_visited), final_path))
    else:
        # No path found
        frames.append((list(all_visited), None))

    # Create figure and axis
    fig, ax = plt.subplots(figsize=(10, 10))
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])

    # Add Exit button
    button_ax = plt.axes([0.8, 0.01, 0.15, 0.05])
    exit_button = Button(button_ax, 'Exit')

    def on_exit_clicked(event):
        plt.close(fig)

    exit_button.on_clicked(on_exit_clicked)

    # Animation function
    def animate(i):
        if i < len(frames):
            current_frame = frames[i]
            update_plot(current_frame)
        return ax,

    def update_plot(frame_data):
        visited_nodes, path = frame_data

        ax.clear()

        # Prepare maze copy for animation
        maze_display = maze.copy()
        maze_display[start] = 2  # 2 represents start
        maze_display[end] = 3  # 3 represents end

        # Display maze
        ax.imshow(maze_display, cmap=cmap)

        # Add grid
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

        # Draw S and E markers
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

        # Draw visited nodes with different colors based on which side visited them
        for side, (y, x) in visited_nodes:
            if (y, x) != start and (y, x) != end:
                if side == 'start':
                    ax.plot(x, y, 'go', markersize=8, alpha=0.5)  # Green for start side
                else:
                    ax.plot(x, y, 'mo', markersize=8, alpha=0.5)  # Magenta for end side

        # If path exists, draw path
        if path:
            path_y = [pos[0] for pos in path]
            path_x = [pos[1] for pos in path]
            ax.plot(path_x, path_y, 'r-', linewidth=3, alpha=0.7)

            # Add numbers to path
            for i, (y, x) in enumerate(path):
                if i > 0 and i < len(path) - 1:  # Skip start and end
                    ax.text(x, y, str(i), color='black', fontsize=9,
                            ha='center', va='center', fontweight='bold')

            ax.set_title(f'Path found! Length: {len(path)}')
        else:
            if len(visited_nodes) > 0 and frames.index(frame_data) == len(frames) - 1 and not final_path:
                ax.set_title('No path found!')
            else:
                ax.set_title('Bidirectional BFS Searching...')

    # Create animation - Set repeat=False to prevent looping
    ani = animation.FuncAnimation(fig, animate, frames=len(frames),
                                  interval=200, blit=True, repeat=False)

    plt.tight_layout()
    plt.show()

    return ani, fig


def run_bidirectional_pathfinding():
    """Run interactive interface with buttons for bidirectional BFS"""
    # Create main window
    fig = plt.figure(figsize=(10, 12))

    # Create grid layout
    grid = plt.GridSpec(8, 1, height_ratios=[5, 0.2, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3])

    # Maze display area
    ax = plt.subplot(grid[0])

    # Button areas
    ax_button1 = plt.subplot(grid[2])
    ax_button2 = plt.subplot(grid[3])
    ax_button3 = plt.subplot(grid[4])
    ax_button4 = plt.subplot(grid[5])

    # Hide axes for button areas
    ax_button1.axis('off')
    ax_button2.axis('off')
    ax_button3.axis('off')
    ax_button4.axis('off')

    # Create maze
    maze = create_correct_maze()

    # Define start and end points
    start = (2, 3)  # S coordinates (row, column)
    end = (4, 7)  # E coordinates (row, column)

    # Initialize variables
    path = None

    # Create maze matrix for display
    maze_display = maze.copy()
    # Mark start and end in visualization
    maze_display[start] = 2  # 2 represents start
    maze_display[end] = 3  # 3 represents end

    # Display initial maze
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
    ax.imshow(maze_display, cmap=cmap)
    ax.grid(color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

    # Draw S and E markers
    ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

    ax.set_title('Robot Path Finding - Initial State')

    # Add buttons
    ax_start_search = plt.axes([0.3, 0.28, 0.4, 0.05])
    ax_show_animation = plt.axes([0.3, 0.22, 0.4, 0.05])
    ax_show_maze = plt.axes([0.3, 0.16, 0.4, 0.05])
    ax_exit = plt.axes([0.3, 0.10, 0.4, 0.05])

    # Create buttons
    btn_start_search = Button(ax_start_search, 'Start Search')
    btn_show_animation = Button(ax_show_animation, 'Show Animation')
    btn_show_maze = Button(ax_show_maze, 'Show Maze Layout')
    btn_exit = Button(ax_exit, 'Exit')

    # Button callbacks
    def on_start_search(event):
        nonlocal path
        ax.set_title("Running Bidirectional BFS algorithm...")
        fig.canvas.draw_idle()
        # Use original maze (without start/end markers) for search
        path = bidirectional_bfs(maze, start, end, ax, fig)
        if not path:
            ax.set_title("No path found!")

    def on_show_animation(event):
        plt.close(fig)  # Close current window
        update_animation_for_bidirectional_bfs(maze, start, end)

    def on_show_maze(event):
        ax.clear()
        # Show maze with color markers
        maze_display = maze.copy()
        maze_display[start] = 2
        maze_display[end] = 3
        ax.imshow(maze_display, cmap=cmap)
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)
        # Show coordinates
        for i in range(maze.shape[0]):
            for j in range(maze.shape[1]):
                ax.text(j, i, f'({i},{j})', ha='center', va='center',
                        color='black', fontsize=7)
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')
        ax.set_title('Maze Layout - Showing Coordinates')
        fig.canvas.draw_idle()

    def on_exit(event):
        plt.close(fig)

    # Connect button callbacks
    btn_start_search.on_clicked(on_start_search)
    btn_show_animation.on_clicked(on_show_animation)
    btn_show_maze.on_clicked(on_show_maze)
    btn_exit.on_clicked(on_exit)

    plt.tight_layout()
    plt.show()

    return maze, start, end, path


def solve_maze_with_bidirectional_bfs():
    """Simple version: directly solve the maze using Bidirectional BFS and display results"""
    # Create maze
    maze = create_correct_maze()

    # Define start and end points
    start = (2, 3)  # S coordinates (row, column)
    end = (4, 7)  # E coordinates (row, column)

    # Use Bidirectional BFS algorithm to find path
    print("Using Bidirectional BFS algorithm to find path...")
    start_time = time.time()
    path = bidirectional_bfs(maze, start, end, visualize=False)
    end_time = time.time()

    if path:
        print(f"Path found! Length: {len(path)}")
        print(f"Path: {path}")
        print(f"Search time: {end_time - start_time:.6f} seconds")
    else:
        print("No path found!")

    # Prepare maze with color markers for display
    maze_display = maze.copy()
    maze_display[start] = 2  # 2 represents start
    maze_display[end] = 3  # 3 represents end

    # Create color map
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])

    # Visualize results
    fig, ax = plt.subplots(figsize=(8, 9))
    ax.imshow(maze_display, cmap=cmap)

    # Add grid
    ax.grid(color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

    # Draw S and E markers
    ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

    # If path exists, draw path
    if path:
        path_y = [pos[0] for pos in path]
        path_x = [pos[1] for pos in path]
        ax.plot(path_x, path_y, 'r-', linewidth=3, alpha=0.7)

        # Add numbers to path
        for i, (y, x) in enumerate(path):
            if i > 0 and i < len(path) - 1:  # Skip start and end
                ax.text(x, y, str(i), color='black', fontsize=9,
                        ha='center', va='center', fontweight='bold')

        ax.set_title(f"Robot Path Finding - Path found! Length: {len(path)}")
    else:
        ax.set_title("Robot Path Finding - No path found!")

    plt.tight_layout()
    plt.show()

    return maze, start, end, path


# 其余必要函数保持不变
def create_correct_maze():
    """Create the 8x9 maze based on the image"""
    # Create an 8-column, 9-row maze (height 9, width 8)
    maze = np.zeros((9, 8), dtype=int)

    # Set obstacles (blue areas)
    # Left vertical obstacle
    maze[1:4, 1] = 1
    maze[7, 1] = 1
    # Top horizontal obstacle
    maze[1, 1:4] = 1
    # Right vertical obstacle
    maze[1:7, 4] = 1
    # Bottom horizontal obstacle
    maze[7, 1:5] = 1

    return maze


if __name__ == "__main__":
    # Select run mode
    print("Please select a run mode:")
    print("1. Simple Mode - Directly display results")
    print("2. Interactive Mode - Provide buttons and animation")

    try:
        choice = int(input("Enter option (1 or 2): "))
        if choice == 1:
            solve_maze_with_bidirectional_bfs()
        elif choice == 2:
            run_bidirectional_pathfinding()
        else:
            print("Invalid option, using Simple Mode as default")
            solve_maze_with_bidirectional_bfs()
    except Exception as e:
        print(f"Input error: {str(e)}")
        print("Using Simple Mode as default")
        solve_maze_with_bidirectional_bfs()