import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button
import matplotlib.animation as animation
from matplotlib.colors import ListedColormap
import heapq
import time


class Node:
    """Node class for A* Pathfinding"""

    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.g = 0  # Cost from start to current node
        self.h = 0  # Heuristic (estimated cost from current node to end)
        self.f = 0  # Total cost: f = g + h

    def __eq__(self, other):
        return self.position == other.position

    def __lt__(self, other):
        return self.f < other.f


def astar(maze, start, end, ax=None, fig=None, visualize=True):
    """
    Returns a list of tuples as a path from the given start to the given end in the given maze
    """
    # Create start and end node
    start_node = Node(None, start)
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, end)
    end_node.g = end_node.h = end_node.f = 0

    # Initialize open and closed lists
    open_list = []
    closed_list = set()  # Using a set for O(1) membership check

    # Add the start node
    heapq.heappush(open_list, start_node)

    # Update visualization with initial state
    if visualize and ax is not None and fig is not None:
        ax.clear()
        # Prepare maze with color markers for display
        maze_display = maze.copy()
        maze_display[start] = 2  # 2 represents start
        maze_display[end] = 3  # 3 represents end

        # Create color map
        cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
        ax.imshow(maze_display, cmap=cmap)

        # Add grid
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

        # Draw S and E markers
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

        ax.set_title('Robot Path Finding - Searching...')
        fig.canvas.draw_idle()

    # Keep track of visited positions for visualization
    visited = []

    # Loop until you find the end
    while open_list:
        # Get the current node
        current_node = heapq.heappop(open_list)

        # Add current position to closed list
        closed_list.add(current_node.position)

        # Add current position to visited
        visited.append(current_node.position)

        # Visualize the search process
        if visualize and ax is not None and fig is not None and len(
                visited) % 5 == 0:  # Update every 5 steps to speed up visualization
            for y, x in visited[-5:]:  # Only plot the new points
                if (y, x) != start and (y, x) != end:
                    ax.plot(x, y, 'yo', markersize=5, alpha=0.3)
            fig.canvas.draw_idle()
            plt.pause(0.001)

        # Found the goal
        if current_node.position == end_node.position:
            path = []
            current = current_node
            while current is not None:
                path.append(current.position)
                current = current.parent

            # Reverse path to get start-to-end order
            path = path[::-1]

            # Visualize the final path
            if visualize and ax is not None and fig is not None:
                path_x = [pos[1] for pos in path]
                path_y = [pos[0] for pos in path]

                # Remove existing path lines if any
                for line in ax.lines:
                    if line.get_label() == 'Path':
                        line.remove()

                ax.plot(path_x, path_y, 'r-', linewidth=2, label='Path')

                # Clear previous path numbers if any
                for txt in ax.texts:
                    if txt.get_text() not in ['S', 'E']:
                        txt.remove()

                for i, (y, x) in enumerate(path):
                    if i > 0 and i < len(path) - 1:  # Skip start and end
                        ax.text(x, y, str(i), color='black', fontsize=8,
                                ha='center', va='center')

                ax.set_title(f"Path found! Length: {len(path)}")
                fig.canvas.draw_idle()

            return path  # Return path immediately when goal is found

        # Generate children
        # Adjacent movements: Up, Down, Left, Right
        for new_position in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
            # Get node position
            node_position = (current_node.position[0] + new_position[0],
                             current_node.position[1] + new_position[1])

            # Make sure within range
            if (node_position[0] < 0 or node_position[0] >= maze.shape[0] or
                    node_position[1] < 0 or node_position[1] >= maze.shape[1]):
                continue

            # Make sure walkable terrain (not an obstacle)
            if maze[node_position[0], node_position[1]] == 1:
                continue

            # Skip if in closed list
            if node_position in closed_list:
                continue

            # Create new node
            new_node = Node(current_node, node_position)

            # Create the f, g, and h values
            new_node.g = current_node.g + 1
            # Heuristic is Manhattan distance to the end
            new_node.h = abs(new_node.position[0] - end_node.position[0]) + abs(
                new_node.position[1] - end_node.position[1])
            new_node.f = new_node.g + new_node.h

            # Check if this node is already in the open list with a better g score
            skip = False
            for i, open_node in enumerate(open_list):
                if open_node.position == new_node.position:
                    if new_node.g >= open_node.g:
                        skip = True
                        break
                    else:
                        # Replace with better node
                        open_list[i] = new_node
                        # Reheapify
                        heapq.heapify(open_list)
                        skip = True
                        break

            if not skip:
                # Add the child to the open list
                heapq.heappush(open_list, new_node)

    # No path found
    if visualize and ax is not None and fig is not None:
        ax.set_title("No path found!")
        fig.canvas.draw_idle()
    return None


def create_correct_maze():
    """Create the 8x9 maze based on the image"""
    # Create an 8-column, 9-row maze (height 9, width 8)
    maze = np.zeros((9, 8), dtype=int)

    # Set obstacles (blue areas)
    # Left vertical obstacle
    maze[1:4, 1] = 1
    maze[7, 1] = 1
    # Top horizontal obstacle
    maze[1, 1:4] = 1
    # Right vertical obstacle
    maze[1:7, 4] = 1
    # Bottom horizontal obstacle
    maze[7, 1:5] = 1

    return maze


def create_animation(maze, start, end):
    """Create animation of path finding process"""
    # Create start and end node
    start_node = Node(None, start)
    start_node.g = start_node.h = start_node.f = 0
    end_node = Node(None, end)
    end_node.g = end_node.h = end_node.f = 0

    # Initialize open and closed lists
    open_list = []
    closed_list = set()

    # Add the start node
    heapq.heappush(open_list, start_node)

    # Record each step's state
    frames = []
    frames.append(([], [], None))  # Initial state: no visited points, no path

    visited = []
    final_path = None

    # Create figure and axis
    fig, ax = plt.subplots(figsize=(10, 10))
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])

    # Add Exit button instead of Return button
    button_ax = plt.axes([0.8, 0.01, 0.15, 0.05])
    exit_button = Button(button_ax, 'Exit')

    def on_exit_clicked(event):
        plt.close(fig)

    exit_button.on_clicked(on_exit_clicked)

    # Animation function
    def animate(i):
        if i < len(frames):
            current_frame = frames[i]
            update_plot(current_frame)
        return ax,

    def update_plot(frame_data):
        visited_nodes, open_nodes, path = frame_data

        ax.clear()

        # Prepare maze copy for animation
        maze_display = maze.copy()
        maze_display[start] = 2  # 2 represents start
        maze_display[end] = 3  # 3 represents end

        # Display maze
        ax.imshow(maze_display, cmap=cmap)

        # Add grid
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

        # Draw S and E markers
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

        # Draw visited nodes only up to current frame
        for y, x in visited_nodes:
            if (y, x) != start and (y, x) != end:
                ax.plot(x, y, 'yo', markersize=8, alpha=0.5)

        # If path exists, draw path
        if path:
            path_y = [pos[0] for pos in path]
            path_x = [pos[1] for pos in path]
            ax.plot(path_x, path_y, 'r-', linewidth=3, alpha=0.7)

            # Add numbers to path
            for i, (y, x) in enumerate(path):
                if i > 0 and i < len(path) - 1:  # Skip start and end
                    ax.text(x, y, str(i), color='black', fontsize=9,
                            ha='center', va='center', fontweight='bold')

            ax.set_title(f'Path found! Length: {len(path)}')
        else:
            if len(visited_nodes) > 0 and frames.index(frame_data) == len(frames) - 1 and not final_path:
                ax.set_title('No path found!')
            else:
                ax.set_title('Searching...')

    def update_frames():
        """Perform A* search and update frames"""
        nonlocal open_list, closed_list, visited, final_path, frames

        # Create a list to track nodes that we've examined (not just visited)
        examined_nodes = []

        # Main search loop
        while open_list:
            # Get the current node with lowest f score
            current_node = heapq.heappop(open_list)

            # Check if reached end immediately
            if current_node.position == end_node.position:
                # Reconstruct path
                path = []
                current = current_node
                while current is not None:
                    path.append(current.position)
                    current = current.parent
                path = path[::-1]

                # Add to visited for visualization
                if current_node.position not in visited:
                    visited.append(current_node.position)

                # Save final path
                final_path = path

                # Record final state with path
                current_open_nodes = list(open_list)
                frames.append((list(visited), [], path))

                # Exit the search loop
                break

            # If not at goal, process this node
            closed_list.add(current_node.position)
            if current_node.position not in visited:
                visited.append(current_node.position)

            # Record current state (only once per several nodes to reduce frame count)
            if len(visited) % 3 == 0:  # Record every 3rd node to reduce animation frames
                current_open_nodes = []  # Don't show open list to simplify visualization
                frames.append((list(visited), current_open_nodes, None))

            # Generate children nodes
            for direction in [(0, -1), (0, 1), (-1, 0), (1, 0)]:  # Adjacent directions
                node_position = (current_node.position[0] + direction[0],
                                 current_node.position[1] + direction[1])

                # Skip if already examined
                if node_position in examined_nodes:
                    continue

                # Add to examined nodes
                examined_nodes.append(node_position)

                # Check if valid position
                if (node_position[0] < 0 or node_position[0] >= maze.shape[0] or
                        node_position[1] < 0 or node_position[1] >= maze.shape[1]):
                    continue

                # Check if walkable
                if maze[node_position[0], node_position[1]] == 1:
                    continue

                # Check if in closed list
                if node_position in closed_list:
                    continue

                # Create new node
                new_node = Node(current_node, node_position)

                # Set g, h, f values
                new_node.g = current_node.g + 1
                new_node.h = abs(node_position[0] - end[0]) + abs(node_position[1] - end[1])
                new_node.f = new_node.g + new_node.h

                # Check if already in open list with better g value
                skip = False
                for i, open_node in enumerate(open_list):
                    if open_node.position == new_node.position:
                        if new_node.g >= open_node.g:
                            skip = True
                            break
                        else:
                            # Replace with better node
                            open_list[i] = new_node
                            heapq.heapify(open_list)
                            skip = True
                            break

                if not skip:
                    heapq.heappush(open_list, new_node)

        # If no path found, add final state
        if not final_path:
            frames.append((list(visited), [], None))

    # Run A* and collect frames
    update_frames()

    # Create animation - Set repeat=False to prevent looping
    ani = animation.FuncAnimation(fig, animate, frames=len(frames),
                                  interval=200, blit=True, repeat=False)

    plt.tight_layout()
    plt.show()

    return ani, fig


def run_pathfinding():
    """Run interactive interface with buttons for search and animation"""
    # Create main window
    fig = plt.figure(figsize=(10, 12))

    # Create grid layout
    grid = plt.GridSpec(8, 1, height_ratios=[5, 0.2, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3])

    # Maze display area
    ax = plt.subplot(grid[0])

    # Button areas
    ax_button1 = plt.subplot(grid[2])
    ax_button2 = plt.subplot(grid[3])
    ax_button3 = plt.subplot(grid[4])
    ax_button4 = plt.subplot(grid[5])

    # Hide axes for button areas
    ax_button1.axis('off')
    ax_button2.axis('off')
    ax_button3.axis('off')
    ax_button4.axis('off')

    # Create maze
    maze = create_correct_maze()

    # Define start and end points
    start = (2, 3)  # S coordinates (row, column)
    end = (4, 7)  # E coordinates (row, column)

    # Initialize variables
    path = None

    # Create maze matrix for display
    maze_display = maze.copy()
    # Mark start and end in visualization
    maze_display[start] = 2  # 2 represents start
    maze_display[end] = 3  # 3 represents end

    # Display initial maze
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])
    ax.imshow(maze_display, cmap=cmap)
    ax.grid(color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

    # Draw S and E markers
    ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

    ax.set_title('Robot Path Finding - Initial State')

    # Add buttons
    ax_start_search = plt.axes([0.3, 0.28, 0.4, 0.05])
    ax_show_animation = plt.axes([0.3, 0.22, 0.4, 0.05])
    ax_show_maze = plt.axes([0.3, 0.16, 0.4, 0.05])
    ax_exit = plt.axes([0.3, 0.10, 0.4, 0.05])

    # Create buttons
    btn_start_search = Button(ax_start_search, 'Start Search')
    btn_show_animation = Button(ax_show_animation, 'Show Animation')
    btn_show_maze = Button(ax_show_maze, 'Show Maze Layout')
    btn_exit = Button(ax_exit, 'Exit')

    # Button callbacks
    def on_start_search(event):
        nonlocal path
        ax.set_title("Running A* algorithm...")
        fig.canvas.draw_idle()
        # Use original maze (without start/end markers) for search
        path = astar(maze, start, end, ax, fig)
        if not path:
            ax.set_title("No path found!")

    def on_show_animation(event):
        plt.close(fig)  # Close current window
        create_animation(maze, start, end)

    def on_show_maze(event):
        ax.clear()
        # Show maze with color markers
        maze_display = maze.copy()
        maze_display[start] = 2
        maze_display[end] = 3
        ax.imshow(maze_display, cmap=cmap)
        ax.grid(color='black', linestyle='-', linewidth=0.5)
        ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
        ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)
        # Show coordinates
        for i in range(maze.shape[0]):
            for j in range(maze.shape[1]):
                ax.text(j, i, f'({i},{j})', ha='center', va='center',
                        color='black', fontsize=7)
        ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
        ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')
        ax.set_title('Maze Layout - Showing Coordinates')
        fig.canvas.draw_idle()

    def on_exit(event):
        plt.close(fig)

    # Connect button callbacks
    btn_start_search.on_clicked(on_start_search)
    btn_show_animation.on_clicked(on_show_animation)
    btn_show_maze.on_clicked(on_show_maze)
    btn_exit.on_clicked(on_exit)

    plt.tight_layout()
    plt.show()

    return maze, start, end, path


def solve_maze_simple():
    """Simple version: directly solve the maze and display results"""
    # Create maze
    maze = create_correct_maze()

    # Define start and end points
    start = (2, 3)  # S coordinates (row, column)
    end = (4, 7)  # E coordinates (row, column)

    # Use A* algorithm to find path
    print("Using A* algorithm to find path...")
    start_time = time.time()
    path = astar(maze, start, end, visualize=False)
    end_time = time.time()

    if path:
        print(f"Path found! Length: {len(path)}")
        print(f"Path: {path}")
        print(f"Search time: {end_time - start_time:.6f} seconds")
    else:
        print("No path found!")

    # Prepare maze with color markers for display
    maze_display = maze.copy()
    maze_display[start] = 2  # 2 represents start
    maze_display[end] = 3  # 3 represents end

    # Create color map
    cmap = ListedColormap(['white', 'blue', 'red', 'gray'])

    # Visualize results
    fig, ax = plt.subplots(figsize=(8, 9))
    ax.imshow(maze_display, cmap=cmap)

    # Add grid
    ax.grid(color='black', linestyle='-', linewidth=0.5)
    ax.set_xticks(np.arange(-0.5, maze.shape[1], 1), minor=True)
    ax.set_yticks(np.arange(-0.5, maze.shape[0], 1), minor=True)

    # Draw S and E markers
    ax.text(start[1], start[0], 'S', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    ax.text(end[1], end[0], 'E', ha='center', va='center', color='black', fontsize=14, fontweight='bold')

    # If path exists, draw path
    if path:
        path_y = [pos[0] for pos in path]
        path_x = [pos[1] for pos in path]
        ax.plot(path_x, path_y, 'r-', linewidth=3, alpha=0.7)

        # Add numbers to path
        for i, (y, x) in enumerate(path):
            if i > 0 and i < len(path) - 1:  # Skip start and end
                ax.text(x, y, str(i), color='black', fontsize=9,
                        ha='center', va='center', fontweight='bold')

        ax.set_title(f"Robot Path Finding - Path found! Length: {len(path)}")
    else:
        ax.set_title("Robot Path Finding - No path found!")

    plt.tight_layout()
    plt.show()

    return maze, start, end, path


if __name__ == "__main__":
    # Select run mode
    print("Please select a run mode:")
    print("1. Simple Mode - Directly display results")
    print("2. Interactive Mode - Provide buttons and animation")

    try:
        choice = int(input("Enter option (1 or 2): "))
        if choice == 1:
            solve_maze_simple()
        elif choice == 2:
            run_pathfinding()
        else:
            print("Invalid option, using Simple Mode as default")
            solve_maze_simple()
    except Exception as e:
        print(f"Input error: {str(e)}")
        print("Using Simple Mode as default")
        solve_maze_simple()