class MIPSSimulator:
    def __init__(self):
        # 初始化32个MIPS寄存器
        self.registers = [0] * 32
        # 寄存器$28初始化为0x10008000
        self.registers[28] = 0x10008000
        # 寄存器$29初始化为0x7fffeffc
        self.registers[29] = 0x7fffeffc
        # 程序计数器(PC)从基址0x00400000开始
        self.pc = 0x00400000
        # 指令内存
        self.instruction_memory = {}
        # 数据内存
        self.data_memory = {}
        # 零寄存器($0)永远为0
        self.registers[0] = 0
        # 指令计数
        self.instructions_executed = 0
        # 调试模式
        self.debug = False

    def read_data_mem(self, address):
        """从数据内存读取一个字"""
        if address not in self.data_memory:
            return 0
        return self.data_memory[address]

    def write_data_mem(self, address, value):
        """向数据内存写入一个字"""
        self.data_memory[address] = value & 0xFFFFFFFF

    def read_instruction(self, address):
        """从指令内存读取一条指令"""
        if address in self.instruction_memory:
            return self.instruction_memory[address]
        if self.debug:
            print(f"  调试: 地址 {address:08x} 处没有指令")
        return 0  # 默认返回NOP指令

    def sign_extend(self, value, bits):
        """将指定位宽的值符号扩展到32位"""
        sign_bit = 1 << (bits - 1)
        return (value & (sign_bit - 1)) - (value & sign_bit)

    def execute_instruction(self, instruction):
        """执行一条MIPS指令"""
        # 提取指令字段
        opcode = (instruction >> 26) & 0x3F
        rs = (instruction >> 21) & 0x1F
        rt = (instruction >> 16) & 0x1F
        rd = (instruction >> 11) & 0x1F
        shamt = (instruction >> 6) & 0x1F
        funct = instruction & 0x3F
        immediate = instruction & 0xFFFF
        address = instruction & 0x3FFFFFF

        # 获取寄存器值
        rs_val = self.registers[rs]
        rt_val = self.registers[rt]

        # 计算下一条指令的地址（默认为PC+4）
        next_pc = self.pc + 4

        # R型指令(opcode 0)
        if opcode == 0:
            if funct == 0x00:  # SLL
                self.registers[rd] = (rt_val << shamt) & 0xFFFFFFFF
            elif funct == 0x02:  # SRL
                self.registers[rd] = (rt_val >> shamt) & 0xFFFFFFFF
            elif funct == 0x03:  # SRA
                # 算术右移（保留符号位）
                if rt_val & 0x80000000:
                    fill = 0xFFFFFFFF << (32 - shamt)
                    self.registers[rd] = ((rt_val >> shamt) | fill) & 0xFFFFFFFF
                else:
                    self.registers[rd] = (rt_val >> shamt) & 0xFFFFFFFF
            elif funct == 0x04:  # SLLV
                shamt = rs_val & 0x1F  # 使用rs的低5位作为移位量
                self.registers[rd] = (rt_val << shamt) & 0xFFFFFFFF
            elif funct == 0x06:  # SRLV
                shamt = rs_val & 0x1F
                self.registers[rd] = (rt_val >> shamt) & 0xFFFFFFFF
            elif funct == 0x07:  # SRAV
                shamt = rs_val & 0x1F
                if rt_val & 0x80000000:
                    fill = 0xFFFFFFFF << (32 - shamt)
                    self.registers[rd] = ((rt_val >> shamt) | fill) & 0xFFFFFFFF
                else:
                    self.registers[rd] = (rt_val >> shamt) & 0xFFFFFFFF
            elif funct == 0x08:  # JR
                next_pc = rs_val
            elif funct == 0x09:  # JALR
                self.registers[rd] = next_pc
                next_pc = rs_val
            elif funct == 0x20:  # ADD
                result = rs_val + rt_val
                # 检查溢出
                if ((rs_val & 0x80000000) == (rt_val & 0x80000000) and
                        (result & 0x80000000) != (rs_val & 0x80000000)):
                    # 发生溢出
                    pass  # 在真实MIPS中会触发异常
                self.registers[rd] = result & 0xFFFFFFFF
            elif funct == 0x21:  # ADDU
                self.registers[rd] = (rs_val + rt_val) & 0xFFFFFFFF
            elif funct == 0x22:  # SUB
                result = rs_val - rt_val
                # 检查溢出
                if ((rs_val & 0x80000000) != (rt_val & 0x80000000) and
                        (result & 0x80000000) != (rs_val & 0x80000000)):
                    # 发生溢出
                    pass  # 在真实MIPS中会触发异常
                self.registers[rd] = result & 0xFFFFFFFF
            elif funct == 0x23:  # SUBU
                self.registers[rd] = (rs_val - rt_val) & 0xFFFFFFFF
            elif funct == 0x24:  # AND
                self.registers[rd] = rs_val & rt_val
            elif funct == 0x25:  # OR
                self.registers[rd] = rs_val | rt_val
            elif funct == 0x26:  # XOR
                self.registers[rd] = rs_val ^ rt_val
            elif funct == 0x27:  # NOR
                self.registers[rd] = ~(rs_val | rt_val) & 0xFFFFFFFF
            elif funct == 0x2A:  # SLT
                # 转换为有符号整数
                signed_rs = rs_val if rs_val < 0x80000000 else rs_val - 0x100000000
                signed_rt = rt_val if rt_val < 0x80000000 else rt_val - 0x100000000
                self.registers[rd] = 1 if signed_rs < signed_rt else 0
            elif funct == 0x2B:  # SLTU
                self.registers[rd] = 1 if rs_val < rt_val else 0

        # I型指令
        elif opcode == 0x08:  # ADDI
            imm_se = self.sign_extend(immediate, 16)
            result = rs_val + imm_se
            # 检查溢出
            if ((rs_val & 0x80000000) == (imm_se & 0x80000000) and
                    (result & 0x80000000) != (rs_val & 0x80000000)):
                # 发生溢出
                pass  # 在真实MIPS中会触发异常
            self.registers[rt] = result & 0xFFFFFFFF
        elif opcode == 0x09:  # ADDIU
            imm_se = self.sign_extend(immediate, 16)
            self.registers[rt] = (rs_val + imm_se) & 0xFFFFFFFF
        elif opcode == 0x0C:  # ANDI
            self.registers[rt] = rs_val & immediate  # 零扩展立即数
        elif opcode == 0x0D:  # ORI
            self.registers[rt] = rs_val | immediate  # 零扩展立即数
        elif opcode == 0x0E:  # XORI
            self.registers[rt] = rs_val ^ immediate  # 零扩展立即数
        elif opcode == 0x0F:  # LUI
            self.registers[rt] = (immediate << 16) & 0xFFFFFFFF
        elif opcode == 0x0A:  # SLTI
            imm_se = self.sign_extend(immediate, 16)
            # 转换为有符号整数
            signed_rs = rs_val if rs_val < 0x80000000 else rs_val - 0x100000000
            signed_imm = imm_se if imm_se < 0x80000000 else imm_se - 0x100000000
            self.registers[rt] = 1 if signed_rs < signed_imm else 0
        elif opcode == 0x0B:  # SLTIU
            imm_se = self.sign_extend(immediate, 16)
            # 无符号比较
            unsigned_rs = rs_val & 0xFFFFFFFF
            unsigned_imm = imm_se & 0xFFFFFFFF
            self.registers[rt] = 1 if unsigned_rs < unsigned_imm else 0
        elif opcode == 0x23:  # LW
            imm_se = self.sign_extend(immediate, 16)
            addr = (rs_val + imm_se) & 0xFFFFFFFF
            self.registers[rt] = self.read_data_mem(addr)
        elif opcode == 0x2B:  # SW
            imm_se = self.sign_extend(immediate, 16)
            addr = (rs_val + imm_se) & 0xFFFFFFFF
            self.write_data_mem(addr, rt_val)
        elif opcode == 0x04:  # BEQ
            imm_se = self.sign_extend(immediate, 16)
            if rs_val == rt_val:
                next_pc = self.pc + 4 + (imm_se << 2)
        elif opcode == 0x05:  # BNE
            imm_se = self.sign_extend(immediate, 16)
            if rs_val != rt_val:
                next_pc = self.pc + 4 + (imm_se << 2)

        # J型指令
        elif opcode == 0x02:  # J
            # J指令使用26位地址字段，左移2位与PC高4位拼接
            next_pc = ((self.pc & 0xF0000000) | (address << 2))
        elif opcode == 0x03:  # JAL
            # 保存返回地址
            self.registers[31] = self.pc + 4
            # 计算跳转地址
            next_pc = ((self.pc & 0xF0000000) | (address << 2))

        # 更新PC
        self.pc = next_pc

        # 确保$0始终为0
        self.registers[0] = 0

        # 增加执行计数
        self.instructions_executed += 1

    def print_registers(self, file=None):
        """打印所有寄存器的内容"""
        for i in range(32):
            line = f"Reg[{i:11d}] = {self.registers[i]:08x}"
            if file:
                file.write(line + "\n")
            else:
                print(line)

    def load_instructions(self, filename):
        """加载十六进制指令到内存"""
        try:
            with open(filename, 'r') as f:
                lines = f.readlines()

            # 清空当前指令内存
            self.instruction_memory.clear()

            # 加载指令
            address = 0x00400000  # 代码段起始地址
            loaded_count = 0

            for line in lines:
                line = line.strip()
                if line and not line.startswith('#'):
                    try:
                        instruction = int(line, 16)
                        self.instruction_memory[address] = instruction
                        address += 4  # 下一条指令地址
                        loaded_count += 1
                    except ValueError:
                        print(f"  警告: 忽略无效的十六进制指令: {line}")

            print(f"  调试: 加载了 {loaded_count} 条指令到内存")
            print(f"  调试: 第一条指令地址: 0x00400000, 内容: {self.instruction_memory.get(0x00400000, 'None')}")

            return loaded_count > 0

        except Exception as e:
            print(f"  加载指令失败: {e}")
            return False

    def run_simulation(self, output_filename="result.txt"):
        """执行模拟器，并输出结果"""
        # 复位状态
        self.pc = 0x00400000
        self.registers = [0] * 32
        self.registers[28] = 0x10008000
        self.registers[29] = 0x7fffeffc
        self.instructions_executed = 0

        print(f"  调试: 开始模拟，初始PC={self.pc:08x}")
        print(f"  调试: 内存中指令数: {len(self.instruction_memory)}")
        if 0x00400000 in self.instruction_memory:
            print(f"  调试: 首条指令: {self.instruction_memory[0x00400000]:08x}")

        with open(output_filename, 'w') as outfile:
            # 执行指令，直到没有更多指令或达到最大执行次数
            max_instructions = 10000  # 防止无限循环

            # 重要修改：跳过第一条指令的输出
            # 首先静默执行第一条指令(0x00400000)
            if 0x00400000 in self.instruction_memory:
                instruction = self.instruction_memory[0x00400000]
                self.execute_instruction(instruction)
                # 不输出任何内容

            # 然后从第二条指令开始正常输出，但关键是先输出PC和指令，然后执行指令
            while self.instructions_executed < max_instructions:
                # 检查当前PC处是否有指令
                if self.pc not in self.instruction_memory:
                    if self.debug:
                        print(f"  调试: PC={self.pc:08x}处没有指令，模拟结束")
                    break

                # 先保存当前PC和指令
                current_pc = self.pc
                instruction = self.instruction_memory[current_pc]

                # 输出当前PC和指令，以及执行前的寄存器状态
                outfile.write(f"PC = {current_pc:08x}, Inst = {instruction:08x}\n")
                self.print_registers(outfile)
                outfile.write("-------------------------------\n")

                # 然后执行指令（这样下一次循环时寄存器状态会更新）
                self.execute_instruction(instruction)

            print(f"  模拟完成，共执行 {self.instructions_executed} 条指令")


def main():
    # 创建模拟器实例
    simulator = MIPSSimulator()
    simulator.debug = True  # 打开调试模式

    # ===== 配置部分 =====
    # 在这里修改输入和输出文件路径
    input_file = "instructions.txt"  # 十六进制指令文件路径
    output_file = "result.txt"  # 输出结果文件路径
    # ==================

    # 加载指令到内存
    if simulator.load_instructions(input_file):
        # 运行模拟器
        simulator.run_simulation(output_file)
        print(f"结果已保存到 {output_file}")
    else:
        print("程序终止")


if __name__ == "__main__":
    main()