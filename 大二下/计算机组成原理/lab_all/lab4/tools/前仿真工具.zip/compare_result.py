#!/usr/bin/env python3
import os
import re
from colorama import Fore, Style, init

# 初始化colorama
init()


def compare_result_files(generated_file, my_file):
    """
    比较两个结果文件，如果有不同则输出差异。
    比较长度按照较短的文件确定。
    """
    # 读取生成的结果文件
    try:
        with open(generated_file, 'r') as f:
            generated_lines = f.readlines()
    except FileNotFoundError:
        print(f"{Fore.RED}错误: 找不到生成的结果文件 {generated_file}{Style.RESET_ALL}")
        return False

    # 读取自己的结果文件
    try:
        with open(my_file, 'r') as f:
            my_lines = f.readlines()
    except FileNotFoundError:
        print(f"{Fore.RED}错误: 找不到自己的结果文件 {my_file}{Style.RESET_ALL}")
        return False

    # 确定比较的行数（取较短的文件长度）
    compare_length = min(len(generated_lines), len(my_lines))

    # 标记是否完全相同
    is_identical = True

    # 当前指令和周期信息
    current_instruction = ""
    current_cycle = 0

    # 逐行比较
    for i in range(compare_length):
        gen_line = generated_lines[i].strip()
        my_line = my_lines[i].strip()

        # 保存当前指令信息，用于错误报告
        if gen_line.startswith("PC ="):
            current_instruction = gen_line
            current_cycle += 1

        # 如果行不同，输出差异
        if gen_line != my_line:
            if is_identical:  # 第一次发现差异时显示文件信息
                print(f"\n{Fore.YELLOW}比较文件: {generated_file} 和 {my_file}{Style.RESET_ALL}")
                is_identical = False

            # # 显示差异信息
            # print(f"{Fore.CYAN}周期 {current_cycle}，指令: {current_instruction}{Style.RESET_ALL}")
            # print(f"{Fore.GREEN}生成结果: {gen_line}{Style.RESET_ALL}")
            # print(f"{Fore.RED}您的结果: {my_line}{Style.RESET_ALL}")
            # print("---")

    # 输出比较结果
    if is_identical:
        print(
            f"{Fore.GREEN}文件 {os.path.basename(generated_file)} 和 {os.path.basename(my_file)} 完全相同！{Style.RESET_ALL}")
        return True
    else:
        print(
            f"{Fore.YELLOW}文件 {os.path.basename(generated_file)} 和 {os.path.basename(my_file)} 存在差异！{Style.RESET_ALL}")
        return False


def find_matching_files():
    """查找所有生成的结果文件和对应的自己的结果文件"""
    # 获取当前目录下所有文件
    all_files = os.listdir('.')

    # 找到所有生成的结果文件（格式：文件名_result.txt）
    generated_files = [f for f in all_files if f.endswith('_result.txt')]

    # 找到所有自己的结果文件（格式：文件名_my.txt）
    my_files = [f for f in all_files if f.endswith('_my.txt')]

    # 匹配文件对
    file_pairs = []
    for gen_file in generated_files:
        # 提取基本文件名（去掉_result.txt后缀）
        base_name = gen_file.replace('_result.txt', '')

        # 构建预期的对应文件名
        expected_my_file = base_name + "_my.txt"

        # 查找是否存在对应的自己的结果文件
        if expected_my_file in my_files:
            file_pairs.append((gen_file, expected_my_file))

    return file_pairs

def main():
    print(f"{Fore.CYAN}开始比较结果文件...{Style.RESET_ALL}")

    # 查找匹配的文件对
    file_pairs = find_matching_files()

    if not file_pairs:
        print(f"{Fore.YELLOW}没有找到匹配的文件对！{Style.RESET_ALL}")
        print("生成的结果文件应该是 '文件名_result.txt' 格式")
        print("您的结果文件应该是 '文件名_my.txt' 格式")
        return

    print(f"{Fore.CYAN}找到 {len(file_pairs)} 对匹配的文件{Style.RESET_ALL}")

    # 统计比较结果
    success_count = 0

    # 逐对比较文件
    for gen_file, my_file in file_pairs:
        if compare_result_files(gen_file, my_file):
            success_count += 1

    # 输出总结
    print(f"\n{Fore.CYAN}比较完成！{Style.RESET_ALL}")
    print(f"总共比较了 {len(file_pairs)} 对文件，其中 {success_count} 对完全相同")

    if success_count == len(file_pairs):
        print(f"{Fore.GREEN}所有文件都完全匹配！{Style.RESET_ALL}")
    else:
        print(f"{Fore.YELLOW}有 {len(file_pairs) - success_count} 对文件存在差异{Style.RESET_ALL}")
    print("应该是有32个的，还有个漏了，懒得管了\n然后的话需要详细的哪里不一样，去解开注释（看文件就知道哪里了）")

if __name__ == "__main__":
    main()