#!/usr/bin/env python3
import os
import sys

# 导入模拟器类
from main import MIPSSimulator


def process_coe_file(coe_file):
    """处理单个COE文件"""
    print(f"处理文件: {coe_file}")

    # 读取COE文件的全部内容
    try:
        with open(coe_file, 'r') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"  错误: 无法读取文件 {coe_file}: {e}")
        return

    # 检查文件是否至少有两行
    if len(lines) < 3:
        print(f"  警告: {coe_file}内容不足，跳过处理")
        return

    # 跳过前两行，处理指令部分
    instructions = []
    for line in lines[2:]:
        # 移除注释部分
        line = line.split('#')[0].split('//')[0]
        # 清理行并移除逗号和分号
        clean_line = line.strip().rstrip(',;')

        # 如果行不为空且长度合适
        if clean_line and len(clean_line) == 8:
            # 检查是否为有效的十六进制字符
            if all(c in '0123456789abcdefABCDEF' for c in clean_line):
                instructions.append(clean_line)
            else:
                print(f"  警告: 跳过无效的十六进制指令: {clean_line}")

    # 如果没有有效指令，跳过处理
    if not instructions:
        print(f"  警告: {coe_file}没有找到有效指令，跳过处理")
        return

    # 确定基本文件名（不含路径和扩展名）
    base_name = os.path.basename(coe_file)
    file_name_without_ext = os.path.splitext(base_name)[0]

    # 创建临时指令文件
    temp_inst_file = f"{file_name_without_ext}_instructions.txt"
    with open(temp_inst_file, 'w') as f:
        for instruction in instructions:
            f.write(f"{instruction}\n")

    # 生成输出文件名
    output_file = f"{file_name_without_ext}_result.txt"

    # 创建一个模拟器实例
    simulator = MIPSSimulator()
    # 打开调试模式
    simulator.debug = True

    # 加载指令并运行模拟
    if simulator.load_instructions(temp_inst_file):
        print(f"  成功加载了 {len(instructions)} 条指令")
        simulator.run_simulation(output_file)
        print(f"  模拟完成，结果已保存到: {output_file}")
    else:
        print(f"  错误: 加载指令失败")

    # 可选：删除临时指令文件
    # try:
    #     os.remove(temp_inst_file)
    # except:
    #     pass


def main():
    # 获取当前目录下所有.coe文件
    coe_files = [f for f in os.listdir('.') if f.endswith('.coe')]

    if not coe_files:
        print("当前目录下没有找到.coe文件!")
        return

    print(f"找到 {len(coe_files)} 个.coe文件，开始处理...")

    # 处理每个文件
    for coe_file in coe_files:
        process_coe_file(coe_file)

    print("所有文件处理完成!")


if __name__ == "__main__":
    main()